﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MoveBob : MonoBehaviour {

    public float speed;
	void Update () {
        if (Input.GetKey(KeyCode.W))
        {
            gameObject.transform.Translate(Vector3.forward * Time.deltaTime * speed);
        }
        if (Input.GetKey(KeyCode.S))
        {
            gameObject.transform.Translate(Vector3.back * Time.deltaTime * speed * (2 / 3f));
        }
        if (Input.GetKey(KeyCode.RightArrow))
        {
            gameObject.transform.Rotate(Vector3.up, -90f);
        }
    }
}
